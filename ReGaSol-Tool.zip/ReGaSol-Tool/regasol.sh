export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.


java -jar ReGaSol.jar $1



